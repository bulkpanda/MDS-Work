# `flagging_utils.py`

> Computes per-student "at-risk" flags from a cohort's assessment forms and writes a multi-sheet, colour-coded Excel flagging dashboard (optionally a companion PDF).

| | |
|---|---|
| **Lines of code** | 2682 |
| **Top-level functions** | 30 (29 distinct names — `_itemCodeCounts` is defined twice) |
| **Classes** | 3 (`FlagSpec`, `CustomFlagSpec`, `FlaggingConfig`) |
| **Module constants** | 31 |
| **Imports from this codebase** | `variableUtils` (imported, never used), `Utils` (`createTable`, `addPlotImage`, `getBannerDrawer`, `getmodeArgs`, `readDf`, `runDdl`, `toInt`, `autoFitColumns`, `_loadSectionMapping`, `_mergeSection` — only the last two are actually used) |
| **Imported by** | `main.ipynb` via `from flagging_utils import *` (line 71 of `main_notebook_code.py`). No other module in the codebase imports it (`cross_edges_in` is empty). |
| **Run how** | Imported by `main.ipynb` via `from flagging_utils import *`; the notebook defines a wrapper `createFlaggingReport(cohort, formType, config, filters)` that calls `getFlagDf` then `saveFlagDfToExcel2`. |

---

## 1. Purpose and role in the pipeline

This module implements the student **flagging** (at-risk detection) logic for the Dental School's clinical/simulation assessment data. It sits at the *end* of the pipeline: something upstream (in `main.ipynb`: `getDataDf(engine, cohort, filters=...)` plus `calcScore(row, SCORE_MAP)`) produces a **cohortDf** — one row per submitted assessment form, already filtered to forms submitted by an assessor and with a `scores` dict column populated. `flagging_utils` consumes that DataFrame and produces three things:

1. **`flagDf`** — one row per student, with aggregated statistics (means, trend slopes, first/last-third averages, rating-level distributions, role and patient counts, clinical-incident counts), one boolean column per active flag, and two risk counters (`high_risk_flag_count`, `low_risk_flag_count`).
2. **`compDf`** (comparison DataFrame) — one row per (student, item_code) for Simulation forms or (student, Section) for Clinic forms, with the student's count, the cohort average count, `pct_of_cohort` and a `behind` boolean.
3. **`thresholds`** — a dict of the actual numeric threshold values used for this run (either taken from the `FlaggingConfig` or auto-derived from the cohort).

`saveFlagDfToExcel2` then renders those into an `.xlsx` workbook. Which flags fire and which sheets are written is entirely data-driven by three registries plus a config object: `FLAG_REGISTRY` (flag key → flag spec), `SHEET_REGISTRY` (sheet key → builder function) and `PRESETS` (named `FlaggingConfig` objects tuned per cohort, e.g. `dds2_clinic`, `dds3_clinic`, `boh2_sim`).

Vocabulary used throughout (Dental School shorthand): **cohort** = a year group such as `DDS2`, `DDS3`, `BOH1`; **formType** = `"Clinic"` or `"Simulation"`; **ES** = entrustment scale (1–4); **GR** = global rating (1–5); **TS** = time management (1–4); **CS** = communication (1–2); **PS** = professionalism (1–2); **Score** = the mean checklist score (0–1) computed upstream by `calcScore`; **CI** = clinical incident; **FTA** = patient "failed to attend"; **item code** = the procedure/assessment item recorded on a form; **Section** = the grouping of item codes taken from the item-section mapping spreadsheet; **CAF** = clinical assessment form. **Operator** vs **Support Operator** are the two student roles on a clinic session.

Nothing in this module touches the database or the network. Its only external file reads are the item-section mapping spreadsheet (indirectly, via `Utils._loadSectionMapping`, which defaults to `variableUtils.itemSectionMappingFile`); its only writes are the `.xlsx` (and optional `.pdf`) it is told to produce.

---

## 2. External dependencies

| Library / resource | Used for |
|---|---|
| `pandas` (`pd`) | All DataFrame aggregation, pivots, `pd.ExcelWriter` (openpyxl engine) |
| `numpy` (`np`) | `np.polyfit` for trend slopes, `np.nan`, `np.nanmean`, `np.mean` |
| `json` | Parsing `item_codes` / `assessor_data` when they arrive as JSON strings |
| `matplotlib.pyplot` (`plt`) | Module-level import; the donut renderer re-imports it locally and forces the `Agg` backend |
| `openpyxl.styles` | `PatternFill`, `Font`, `Alignment`, `Border`, `Side` (`GradientFill` imported but unused) |
| `openpyxl.styles.numbers.FORMAT_NUMBER_00` | Imported, never used |
| `openpyxl.utils.get_column_letter` | Column-width / anchor addressing |
| `openpyxl.drawing.image.Image` | Local import in `_build_item_scale_donut_sheet` — embeds donut PNGs |
| `reportlab` | Local import in `saveFlagDfToPdf` — landscape A4 PDF companion report |
| `dataclasses.dataclass` | `FlagSpec`, `CustomFlagSpec` |
| `typing` (`Callable`, `List`, `Optional`) | Only `Callable` is used |
| `os`, `re` | Imported, never used |
| `Utils._loadSectionMapping` / `Utils._mergeSection` | Reads the item-code → Section mapping Excel file and merges it onto item-code rows |
| `variableUtils` | Imported but never referenced here (it is `Utils` that reads `variableUtils.itemSectionMappingFile`) |
| **Filesystem** | Reads the item-section mapping `.xlsx`; writes the flagging workbook to the `filepath` given, and `filepath.replace(".xlsx", ".pdf")` when `config.createPdf` is true |
| **Env vars / DB** | None used directly |

---

## 3. Module-level constants and variables

### 3.1 Palette and fonts (lines 20–34)

| Name | Type | Value / shape | Purpose |
|---|---|---|---|
| `_NAVY` | `str` | `"010D44"` | University navy — banner/header fills |
| `_WHITE` | `str` | `"FFFFFF"` | White fill / header text |
| `_RED_BG` | `str` | `"FFC7CE"` | Fill for "below threshold" / high-tier flag triggered |
| `_RED_TEXT` | `str` | `"9C0006"` | Font colour paired with `_RED_BG` |
| `_AMBER_BG` | `str` | `"FFEB9C"` | Fill for "within 10 % of threshold" / low-tier flag triggered |
| `_AMBER_TEXT` | `str` | `"9C6500"` | Font colour paired with `_AMBER_BG` |
| `_GREEN_BG` | `str` | `"C6EFCE"` | Fill for "no issue" |
| `_GREEN_TEXT` | `str` | `"276221"` | Font colour paired with `_GREEN_BG` |
| `_LIGHT_GREY` | `str` | `"F2F2F2"` | Alternating (zebra) row fill |
| `_MID_GREY` | `str` | `"D9D9D9"` | Thin-border colour |
| `_INFO_BG` | `str` | `"DDEBF7"` | Light blue — info-only flags (shown but not scored) |
| `_INFO_TEXT` | `str` | `"1F4E79"` | Dark blue text for info flags |
| `_HEADER_FONT` | `openpyxl Font` | Arial 10 bold white | Column-header font |
| `_BODY_FONT` | `openpyxl Font` | Arial 9 | Default body font |
| `_BOLD_BODY` | `openpyxl Font` | Arial 9 bold | Emphasised body cells |

### 3.2 Flag registry and risk tiers (lines 241–345)

| Name | Type | Value / shape | Purpose |
|---|---|---|---|
| `FLAG_REGISTRY` | `dict[str, FlagSpec \| CustomFlagSpec]` | 18 flag keys | The catalogue of every available flag. `FlaggingConfig.flags` holds keys into this dict. See the full rule table in §5.4. |
| `DEFAULT_HIGH_TIER_FLAGS` | `list[str]` | 7 keys | Flags counted in `high_risk_flag_count` unless a config overrides |
| `DEFAULT_LOW_TIER_FLAGS` | `list[str]` | 11 keys | Flags counted in `low_risk_flag_count` unless a config overrides |

```python
DEFAULT_HIGH_TIER_FLAGS = [
    "low_es", "low_gr", "low_score", "low_form_count",
    "clinical_incident", "low_pt_seen", "high_es_lvl1",
]
DEFAULT_LOW_TIER_FLAGS = [
    "low_ts", "low_cs", "low_ps",
    "declining_es", "declining_gr", "declining_score",
    "no_improvement_es", "no_improvement_gr",
    "low_operator_pct", "high_fta", "high_es_lvl2",
]
```

The comment block at lines 324–335 states the contract: every scored (non-info) flag should appear in exactly one of the two lists; a flag in neither still fires and still shows in Excel but counts toward neither risk column, and `getFlagDf` prints a warning when that happens (line 2328).

### 3.3 ID columns (lines 355–356)

| Name | Type | Value | Purpose |
|---|---|---|---|
| `_ID_COLS` | `list[str]` | `["student_number", "student_name"]` | Leading columns on nearly every sheet |
| `_ID_FRIENDLY` | `dict` | `{"student_number": "ID", "student_name": "Student"}` | Display names for those columns |

### 3.4 DDS3 reportable items and scale labels (lines 987–1013)

| Name | Type | Value / shape | Purpose |
|---|---|---|---|
| `DDS3_REPORTABLE_ITEMS` | `dict[str, list[str]]` | 9 categories → 51 item codes total; sourced from *DDS3 Reportable Item numbers.xlsx*, dated 2026-07 in the comment | Defines which item codes appear on the DDS3-specific sheets and in what category order |
| `_DDS3_ITEM_TO_CAT` | `dict[str, str]` | Flat inversion of the above, 51 entries | `"511" -> "Restorative"` |
| `_SCORE_TO_LABEL` | `dict[str, str]` | 6 entries | Maps raw `assessor_data` scale codes to labels |
| `_SCALE_LABELS` | `list[str]` | 6 labels in fixed display order | Column order for the scale-distribution sheet |

```python
DDS3_REPORTABLE_ITEMS = {
    "Diagnostics":  ['011', '012', '013', '015', '022'],
    "Preventative": ['114', '161'],
    # ... Perio, Oral Surg, Endodontics, Restorative, Fixed Pros, Pros ...
    "General":      ['965'],
}
_SCORE_TO_LABEL = {"O1": "Done Well", "O2": "Done", "O3": "Mostly",
                   "O4": "Sometimes", "O5": "Not Done", "O6": "Not Observed"}
_SCALE_LABELS = ["Done Well", "Done", "Mostly", "Sometimes", "Not Done", "Not Observed"]
```

### 3.5 Donut chart constants (lines 1430–1433)

| Name | Type | Value | Purpose |
|---|---|---|---|
| `_PIE_SCALE_COLORS` | `list[str]` | `["#2E75B6", "#70AD47", "#FFD966", "#ED7D31", "#FF3333", "#BFBFBF"]` | O1 blue, O2 green, O3 amber, O4 orange, O5 red, O6 grey |
| `_PIE_SCALE_KEYS` | `list[str]` | `["O1", "O2", "O3", "O4", "O5", "O6"]` | Slice order, aligned with the colour list |
| `_PIE_PX` | `int` | `52` | Pixel width/height of each embedded donut image |

### 3.6 Sheet registry and presets (lines 1630–2113)

| Name | Type | Value / shape | Purpose |
|---|---|---|---|
| `SHEET_REGISTRY` | `dict[str, Callable]` | 12 sheet keys → builder functions | `FlaggingConfig.sheets` holds keys into this dict; `saveFlagDfToExcel2` iterates it in config order |
| `_ALL_FLAGS` | `list[str]` | `list(FLAG_REGISTRY.keys())` — all 18 | Convenience for presets |
| `_ALL_SHEETS` | `list[str]` | `list(SHEET_REGISTRY.keys())` — all 12 | Convenience for presets |
| `PRESETS` | `dict[str, FlaggingConfig]` | 8 named configs | Ready-made per-cohort configurations |

```python
SHEET_REGISTRY = {
    "summary": _build_summary_sheet, "scale_trends": _build_scale_trends_sheet,
    "level_distribution": _build_level_distribution_sheet, "comparison": _build_comparison_sheet,
    "count_pivot": _build_count_pivot_sheet, "gr_pivot": _build_gr_pivot_sheet,
    "clinical_incidents": _build_clinical_incidents_sheet, "legend": _build_legend_sheet,
    "reportable_items_pivot": _build_reportable_items_pivot_sheet,
    "item_scale_dist": _build_item_scale_dist_sheet,
    "operator_by_clinic": _build_operator_by_clinic_sheet,
    "item_scale_donuts": _build_item_scale_donut_sheet,
}
```

The 8 presets are `clinic_full`, `clinic_quick`, `sim_standard`, `boh2_sim`, `boh2_clinic`, `at_risk_only`, `trends_only`, `dds2_clinic`, `dds3_clinic` — see §4.3 for the full numeric comparison table.

---

## 4. Classes

### `FlagSpec`

`@dataclass`, no base classes. *Lines 220–229.* A simple threshold-comparison flag: it fires when `flagDf[col] < thresholds[thresh_key]` (direction `"below"`) or `> ` (direction `"above"`).

| Attribute | Type | Meaning |
|---|---|---|
| `name` | `str` | Boolean column written to `flagDf`, e.g. `"flag_low_es"` |
| `col` | `str` | Column in `flagDf` to compare, e.g. `"avg_es"` |
| `thresh_key` | `str` | Key into the `thresholds` dict, e.g. `"es"` |
| `direction` | `str` | `"below"` or `"above"` |
| `label` | `str` | Short header used in Excel/PDF flag columns |
| `description` | `str` | Longer text shown on the Legend sheet |

No methods. Evaluated in `getFlagDf` at lines 2305–2310.

### `CustomFlagSpec`

`@dataclass`, no base classes. *Lines 231–237.* A flag computed by an arbitrary function rather than a threshold comparison.

| Attribute | Type | Meaning |
|---|---|---|
| `name` | `str` | Boolean column written to `flagDf` |
| `fn` | `Callable` | `fn(row: pd.Series, thresholds: dict) -> bool`, applied row-wise |
| `label` | `str` | Short header |
| `description` | `str` (default `""`) | Legend text |

Three flags use this: `no_improvement_es`, `no_improvement_gr`, `clinical_incident`.

### `FlaggingConfig`

*Lines 1649–1909.* No base classes. Full specification for one flagging run: which flags, which sheets, which thresholds, which tier classification. The docstring gives a quickstart (use a preset, `.copy(...)` to override one field, build from scratch, `.describe()` to inspect).

#### Attributes (all set in `__init__`, lines 1676–1732)

| Attribute | Default | Meaning |
|---|---|---|
| `flags` | *(required)* | List of keys into `FLAG_REGISTRY`; stored as a new `list` |
| `sheets` | *(required)* | List of keys into `SHEET_REGISTRY`, in output order |
| `esThreshold` | `None` | ES avg cut-off. `None` → auto (borderline method, see §5.5) |
| `grThreshold` | `None` | GR avg cut-off. `None` → auto (mean − SD method only) |
| `tsThreshold` | `None` | TS avg cut-off. `None` → auto (borderline method) |
| `csThreshold` | `None` | CS avg cut-off. `None` → auto (borderline method) |
| `psThreshold` | `None` | PS avg cut-off. `None` → auto (borderline method) |
| `scoreThreshold` | `None` | Checklist score avg cut-off. `None` → auto (borderline method) |
| `minForms` | `None` | Minimum submitted forms. `None` → `int(mean − 1·SD)` of `form_count` |
| `slopeThreshold` | `0.0` | Slope cut-off for the three `declining_*` flags |
| `improvementMargin` | `0.0` | Margin added to the first-third average in the `no_improvement_*` rules |
| `behindRatio` | `0.5` | An item/section is "behind" if the student's count `<` cohort average × this |
| `minOperatorPct` | `50.0` | Minimum % of forms in the Operator role |
| `maxFtaPct` | `30.0` | Maximum % of forms where the patient FTA'd |
| `info_flags` | `None` → `[]` | Flag keys shown in Excel/PDF but excluded from **both** risk counts |
| `minPtSeen` | `None` | Minimum patients seen. `None` → `round(mean − 1·SD, 1)` of `patient_seen` |
| `maxEsLvl1Pct` | `20.0` | Fire `high_es_lvl1` if `es_lvl1_pct >` this |
| `maxEsLvl2Pct` | `100.0` | Fire `high_es_lvl2` if `es_lvl2_pct >` this (100.0 effectively disables it) |
| `sdMultiplier` | `1.0` | Multiplier on SD in the legacy auto-threshold formula `mean − mult·SD` |
| `createPdf` | `False` | Also generate the companion PDF via `saveFlagDfToPdf` |
| `borderlineGrLevel` | `2` | GR level defining the "borderline" peer group (GR scale: 2 = Borderline) |
| `useBorderlineThreshold` | `True` | If true, ES/TS/CS/PS/Score auto-thresholds use the borderline-peer mean instead of `mean − mult·SD`; falls back to the SD method if the borderline group is empty. GR / forms / operator % / FTA % / pt-seen are **never** affected |
| `highTierFlags` | `None` → `DEFAULT_HIGH_TIER_FLAGS` | Keys counted in `high_risk_flag_count` |
| `lowTierFlags` | `None` → `DEFAULT_LOW_TIER_FLAGS` | Keys counted in `low_risk_flag_count` |

#### Methods

| Signature | One line |
|---|---|
| `__init__(self, flags, sheets, esThreshold=None, grThreshold=None, tsThreshold=None, csThreshold=None, psThreshold=None, scoreThreshold=None, minForms=None, slopeThreshold=0.0, improvementMargin=0.0, behindRatio=0.5, minOperatorPct=50.0, maxFtaPct=30.0, info_flags=None, minPtSeen=None, maxEsLvl1Pct=20.0, maxEsLvl2Pct=100.0, sdMultiplier=1.0, createPdf=False, borderlineGrLevel=2, useBorderlineThreshold=True, highTierFlags=None, lowTierFlags=None)` | Stores every setting; list arguments are copied |
| `resolve_flags(self)` | Ordered `[FlagSpec \| CustomFlagSpec]` for `self.flags`; **raises `KeyError`** listing all available keys if a key is unknown |
| `resolve_tiers(self)` | Returns `(high_names, low_names)` sets of `flagDf` column names; a key in both lists is treated as HIGH with a printed warning; unknown keys are ignored with a printed warning |
| `unclassified_flags(self)` | Active, non-info flag keys that are in neither tier list |
| `resolve_sheets(self)` | Ordered list of builder callables; **raises `KeyError`** if a sheet key is unknown |
| `copy(self, **overrides)` | New `FlaggingConfig` with every field copied then `overrides` applied |
| `describe(self)` | Prints a 62-char-wide human-readable audit of flags, info flags, both tiers, unclassified flags, borderline settings, sheets and thresholds |
| `__repr__(self)` | `FlaggingConfig(flags=…, sheets=…, esThreshold=…, grThreshold=…, minForms=…)` |

**Side effects:** `resolve_tiers`, `unclassified_flags` (via `resolve_tiers`) and `describe` all `print()`. `describe`'s threshold table hard-codes the note "auto = cohort mean - 1 SD" (lines 1880–1892) even when `sdMultiplier != 1.0`.

#### 4.3 `PRESETS` compared

| Preset | Flags | Sheets | es | gr | score | minForms | minOp% | maxFTA% | ESL1% | ESL2% | sdMult | borderline |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `clinic_full` | all 18 | all 12 | 2.3 | 2.5 | auto | auto | 65.0 | 25.0 | 20.0 | 100.0 | 1.0 | lvl 2, on |
| `clinic_quick` | `low_es, low_gr, low_form_count, high_fta, clinical_incident` | `summary, legend` | 2.3 | 2.5 | auto | auto | 65.0 | 30.0 | 20.0 | 100.0 | 1.0 | lvl 2, on |
| `sim_standard` | 11 (no operator/FTA/pt-seen flags) | 7 (no comparison/DDS3 sheets) | 2 | 2.5 | 0.6 | auto | 50.0 | 30.0 | **40.0** | 100.0 | 1.5 | lvl 2, on |
| `boh2_sim` | same 11 as `sim_standard` | same 7 | 2 | 2.5 | 0.6 | auto | 50.0 | 30.0 | 20.0 | 100.0 | 1.5 | lvl 2, on |
| `boh2_clinic` | 13 (no `low_ts`, no `high_fta`; uses `low_pt_seen`) | all but `reportable_items_pivot`, `item_scale_dist`, `operator_by_clinic` | 2 | 2.5 | auto | auto | 65.0 | 30.0 | 20.0 | 100.0 | 1.5 | lvl 2, on |
| `at_risk_only` | all 18 | `summary` | 2.3 | 2.5 | auto | auto | 65.0 | 30.0 | 20.0 | 100.0 | 1.0 | lvl 2, on |
| `trends_only` | 5 `declining_*`/`no_improvement_*` | `summary, scale_trends, legend` | auto | auto | auto | auto | 50.0 | 30.0 | 20.0 | 100.0 | 1.0 | lvl 2, on |
| `dds2_clinic` | 13, `info_flags=["low_cs"]` | all 12 | auto | 2.5 | auto | auto | 65.0 | 30.0 | 20.0 | 100.0 | 1.5 | lvl 2, on |
| `dds3_clinic` | 13, `info_flags=["no_improvement_es","no_improvement_gr"]` | 10 (adds the 3 DDS3 sheets + donuts, drops the pivots) | auto | 2.5 | auto | auto | 65.0 | 30.0 | **0.0** | 100.0 | 1.5 | **lvl 3**, on |

Notable per-preset comments in the source: `low_ts` is deliberately excluded from `dds2_clinic`/`boh2_clinic` ("not appropriate at DDS2 clinic level", line 2042); `high_fta` is deliberately replaced by `low_pt_seen` there ("more clinically meaningful", line 2048); `dds3_clinic` drops `low_ts`/`low_cs`/`low_ps` because "the new CAF does not require these" (line 2077) and demotes `no_improvement_*` to info flags to avoid double-counting with `declining_*` (lines 2070–2071).

---

## 5. Function reference

### 5.1 Low-level helpers (lines 40–173)

#### `_fill(hex_color)`

*Lines 40–41.* Returns a solid `PatternFill` in the given RRGGBB (or AARRGGBB) hex string.

**Called by** — every sheet builder plus `_styleHeader`, `_styleColumnHeaders`, `_colorPivotLowCells`.

#### `_thin_border()`

*Lines 44–46.* Returns a `Border` with thin `_MID_GREY` sides on all four edges.

**Called by** — all sheet builders and `_styleColumnHeaders`.

#### `_computeSlope(series)`

*Lines 49–54.* Least-squares linear trend of a numeric series.

**Behaviour** — 1. Drops NaN. 2. Returns `np.nan` if fewer than **2** values remain. 3. Fits `np.polyfit(x, vals, 1)` where `x = 0..n-1` (i.e. *position in the chronologically sorted form order*, not calendar time) and returns the gradient as a `float`.

**Called by** — `getFlagDf` (for `es_slope`, `gr_slope`, `score_slope`).

#### `_itemCodeCounts(cohortDf)` — first definition

*Lines 57–69.* Explodes the `item_codes` list column into a long `(student_number, item_code, count)` table. Skips rows where `item_codes` is not a non-empty `list`, and skips falsy codes. Returns an empty DataFrame **with** columns `["student_number","item_code","count"]` when there is nothing to count.

> **This definition is dead.** A second `def _itemCodeCounts(df)` at line 2385 rebinds the name at import time, so every caller resolves to the later version (§5.7).

#### `_levelDistribution(series, levels)`

*Lines 72–77.* Returns `{lvl: pct}` — the percentage of non-null values equal to each level, rounded to 1 dp; all-NaN input returns `{lvl: np.nan}`.

> **Unused.** `getFlagDf` defines its own nested `_lvl_dist` (line 2181) which returns `0.0` rather than `np.nan` for empty input.

#### `_buildCountPivot(cohortDf, formType, mappingFile=None)`

*Lines 80–118.* Student × item_code (Simulation) or student × Section (Clinic) **count** pivot.

**Parameters**

| Name | Type | Default | Description |
|---|---|---|---|
| `cohortDf` | `DataFrame` | — | Form-level rows with `item_codes`, `student_number`, `student_name` |
| `formType` | `str` | — | `"Clinic"` triggers section mapping; anything else groups by raw item code |
| `mappingFile` | path or `None` | `None` | Passed to `Utils._loadSectionMapping`; `None` uses `variableUtils.itemSectionMappingFile` |

**Returns** — `(pivot, groupCol)` where `groupCol` is `"Section"` or `"Item Code"`; `(empty DataFrame, None)` if there are no item codes.

**Behaviour** — 1. Long counts via `_itemCodeCounts`. 2. Merges student names by `student_number` (uses `drop_duplicates()` on the (number, name) pair, *not* `_canonicalNameMap`). 3. For Clinic, resolves each code to a Section with an inner `_resolve`: exact match first, else split on `/` and take the first part, else if the part before `-` is all digits use that, else `"Unmapped"`. 4. `pivot_table(..., aggfunc="sum", fill_value=0)`. 5. Adds a `Total` column summing everything from column index 2 onward. 6. Sorts by `student_name`.

**Calls** — `flagging_utils:_itemCodeCounts`, `Utils:_loadSectionMapping`. **Called by** — `_build_count_pivot_sheet`.

##### Nested

| Name | Signature | One line |
|---|---|---|
| `_resolve` | `_resolve(code)` | Item code → Section, with `/` and `-` fallbacks; `"Unmapped"` when unknown (Clinic branch only) |

#### `_buildGrPivot(cohortDf, formType, mappingFile=None)`

*Lines 121–173.* Same shape as `_buildCountPivot`, but cell values are the **mean global rating** for that student × item/section, rounded to 2 dp.

**Behaviour** — 1. Builds a long frame with one row per (form × item code) carrying that form's numeric `global_rating`. 2. Resolves Sections for Clinic exactly as above (the `_resolve` body is duplicated verbatim). 3. `pivot_table(..., aggfunc="mean", fill_value=np.nan)`. 4. Rounds and sorts by name.

**Returns** — `(pivot, groupCol)`, or `(empty DataFrame, None)`.

**Calls** — `Utils:_loadSectionMapping`. **Called by** — `_build_gr_pivot_sheet`.

### 5.2 Excel styling helpers (lines 179–214)

#### `_styleHeader(ws, row, ncols, text)`

*Lines 179–186.* Merges `row` across `ncols` columns and writes `text` as a navy banner: Arial 14 bold white, centred, row height 28.

**Side effects** — mutates the worksheet.

#### `_styleColumnHeaders(ws, row, cols, friendly_map=None)`

*Lines 189–198.* Writes each column name (translated through `friendly_map` if present) into `row`, navy fill, `_HEADER_FONT`, centred + wrapped, thin border, row height 30.

#### `_colorPivotLowCells(ws, pivotDf, data_start_col, data_start_row, low_percentile=0.25)`

*Lines 201–214.* Highlights the bottom quartile per column.

**Behaviour** — For each numeric column from `data_start_col` onwards: compute `threshold = col.quantile(low_percentile)`; every cell with `pd.notna(val) and val <= threshold and threshold > 0` gets `_RED_BG` + bold red text. The `threshold > 0` guard means a column whose 25th percentile is 0 is left uncoloured entirely.

**Called by** — `_build_count_pivot_sheet` (with `low_percentile=0.25`).

### 5.3 Name canonicalisation (lines 359–385)

#### `_canonicalNameMap(df)`

*Lines 359–385.* Maps each `student_number` to **one** canonical `student_name`.

**Returns** — `dict {student_number: student_name}`; `{}` if `df` is `None`/empty or lacks either column.

**Behaviour** — 1. Drops rows with null `student_number`, fills null names with `""`. 2. Records original row order in `_ord`. 3. Groups by (number, name), counting occurrences (`_n`) and first appearance (`_first`). 4. Sorts by `_n` descending then `_first` ascending and keeps the first row per number — i.e. **most frequent spelling wins, ties broken by first appearance**, so the result is deterministic. The docstring cites `'Hunain Jamal'` vs `'Hunain JAmal'` as the motivating case.

**Called by** — `getFlagDf`, `_buildItemCountPivot`.

### 5.4 The flag rules — exact criteria

This is the authoritative table. All comparisons are **strict** (`<` / `>`), evaluated in `getFlagDf` lines 2304–2312. `thresholds[...]` values come from §5.5.

| Flag key | `flagDf` column | Fires when | Threshold source (config field) | Label | Default tier |
|---|---|---|---|---|---|
| `low_es` | `flag_low_es` | `avg_es < thresholds["es"]` | `esThreshold`, else borderline auto | `Low ES` | High |
| `low_gr` | `flag_low_gr` | `avg_gr < thresholds["gr"]` | `grThreshold`, else `mean − sdMultiplier·SD` | `Low GR` | High |
| `low_ts` | `flag_low_ts` | `avg_ts < thresholds["ts"]` | `tsThreshold`, else borderline auto | `Low TS` | Low |
| `low_cs` | `flag_low_cs` | `avg_cs < thresholds["cs"]` | `csThreshold`, else borderline auto | `Low CS` | Low |
| `low_ps` | `flag_low_ps` | `avg_ps < thresholds["ps"]` | `psThreshold`, else borderline auto | `Low PS` | Low |
| `low_score` | `flag_low_score` | `avg_score < thresholds["score"]` | `scoreThreshold`, else borderline auto | `Low Score` | High |
| `low_form_count` | `flag_low_form_count` | `form_count < thresholds["forms"]` | `minForms`, else `int(mean − 1·SD)` | `Low Frm` | High |
| `declining_es` | `flag_declining_es` | `es_slope < thresholds["slope"]` | `slopeThreshold` (default `0.0`) | `↓ES` | Low |
| `declining_gr` | `flag_declining_gr` | `gr_slope < thresholds["slope"]` | `slopeThreshold` | `↓GR` | Low |
| `declining_score` | `flag_declining_score` | `score_slope < thresholds["slope"]` | `slopeThreshold` | `↓Score` | Low |
| `no_improvement_es` | `flag_no_improvement_es` | `last_third_es <= first_third_es + thresholds["improvement_margin"]` | `improvementMargin` (default `0.0`) | `No↑ES` | Low |
| `no_improvement_gr` | `flag_no_improvement_gr` | `last_third_gr <= first_third_gr + thresholds["improvement_margin"]` | `improvementMargin` | `No↑GR` | Low |
| `low_operator_pct` | `flag_low_operator_pct` | `pct_operator < thresholds["min_operator_pct"]` | `minOperatorPct` (default `50.0`) | `Low Op%` | Low |
| `high_fta` | `flag_high_fta` | `pct_fta > thresholds["max_fta_pct"]` | `maxFtaPct` (default `30.0`) | `Hi FTA` | Low |
| `clinical_incident` | `flag_clinical_incident` | `ci_count > 0` | — (custom fn) | `CI` | High |
| `low_pt_seen` | `flag_low_pt_seen` | `patient_seen < thresholds["min_pt_seen"]` | `minPtSeen`, else `round(mean − 1·SD, 1)` | `Low Pt Seen` | High |
| `high_es_lvl1` | `flag_high_es_lvl1` | `es_lvl1_pct > thresholds["max_es_lvl1_pct"]` | `maxEsLvl1Pct` (default `20.0`) | `ES L1%` | High |
| `high_es_lvl2` | `flag_high_es_lvl2` | `es_lvl2_pct > thresholds["max_es_lvl2_pct"]` | `maxEsLvl2Pct` (default `100.0`) | `ES L2%` | Low |

Notes that materially change who gets flagged:

- **NaN never flags.** All three of `avg_*`, `*_slope` and the level percentages can be `NaN` (a student with one form has `NaN` slopes; a student with no ES ratings has `NaN` `avg_es`). Pandas comparisons against `NaN` are `False`, so those students silently escape the corresponding flag.
- **`no_improvement_*` uses `<=`,** so a perfectly flat trajectory fires it, and with the default `improvementMargin = 0.0` any student who did not strictly improve is flagged.
- **`high_es_lvl2` at the default `maxEsLvl2Pct = 100.0` can never fire** (a percentage cannot exceed 100). Every preset that includes the flag leaves it at 100.0 — including `dds3_clinic`, which lists `high_es_lvl2` in both `flags` and `lowTierFlags`.
- **`dds3_clinic` sets `maxEsLvl1Pct = 0.0`**, so `high_es_lvl1` fires for *any* student with at least one ES level-1 rating.
- **`patient_fta` counts any `patient_details` value containing the substring `"FTA"` (case-insensitive)**, whereas `patient_seen` requires the exact string `"I saw a patient"`.

### 5.5 Threshold resolution — exact formulas

Computed in `getFlagDf` lines 2246–2296 and printed to stdout (lines 2298–2300).

```python
def _auto(col, override):                      # legacy SD method
    m, s = flagDf[col].mean(), flagDf[col].std()
    mult = config.sdMultiplier or 1.0
    return override if override is not None else round(m - mult * s, 3)
```

Borderline peer group (lines 2251–2270): `_borderlineMask = flagDf["avg_gr"].round() == config.borderlineGrLevel` (default level 2 = "Borderline"; `dds3_clinic` uses 3 = "Satisfactory"). `_borderlineN` is the size of that group.

```python
def _autoBorderline(col, override):
    if override is not None:                      return override
    if config.useBorderlineThreshold and _borderlineN > 0 and col in _borderlineGrp:
        bl_vals = _borderlineGrp[col].dropna()
        if not bl_vals.empty:                     return round(float(bl_vals.mean()), 3)
    return _auto(col, None)                       # fallback
```

| `thresholds` key | Formula when the config field is `None` | Method |
|---|---|---|
| `es` | mean `avg_es` of borderline-GR peers | `_autoBorderline` |
| `gr` | `round(mean(avg_gr) − sdMultiplier·SD(avg_gr), 3)` | `_auto` **only** — never borderline |
| `ts`, `cs`, `ps`, `score` | mean of that column among borderline-GR peers | `_autoBorderline` |
| `forms` | `int(mean(form_count) − SD(form_count))` — **no `sdMultiplier`, no rounding, truncated toward zero** | inline |
| `min_pt_seen` | `round(mean(patient_seen) − SD(patient_seen), 1)`, or `0.0` if the column is missing/all-NaN — **no `sdMultiplier`** | inline |
| `slope`, `improvement_margin`, `behind_ratio`, `min_operator_pct`, `max_fta_pct`, `max_es_lvl1_pct`, `max_es_lvl2_pct` | copied straight from the config; never auto-derived | — |
| `sd_multiplier` | `config.sdMultiplier or 1.0` (so `0.0` becomes `1.0`) | — |
| `borderline_gr_level`, `borderline_n`, `borderline_threshold_on` | recorded for the Legend sheet | — |

### 5.6 Sheet builders

Every builder has the identical signature
`builder(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
and is registered by short key in `SHEET_REGISTRY`. All of them **write into the open `pd.ExcelWriter`** (side effect) and several return early without writing anything when their input is empty.

#### `_build_summary_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`

*Lines 388–549.* Sheet **"Summary"** — the risk-ranked student overview, the sheet people actually read.

**Behaviour** — 1. Columns are `_ID_COLS` + `form_count, operator_count, support_count, pct_operator, patient_seen, patient_fta, pct_fta, ci_count, high_risk_flag_count, low_risk_flag_count, avg_es, avg_gr, avg_ts, avg_cs, avg_ps, avg_score` + one column per active flag + `flags_detail`. 2. Flag booleans are rendered as `"✓"` / `""`. 3. Data starts at row 4 (banner row 1, headers row 3); zebra striping on even rows. 4. `high_risk_flag_count` gets a white→red gradient: `intensity = int(255 − (val / max_high) * 120)` → fill `FF{i:02X}{i:02X}`; `low_risk_flag_count` gets white→amber: `g = int(255 − frac·(255−0xEB))`, `b = int(255 − frac·(255−0x9C))`. 5. Each `avg_*` cell is red below its threshold, amber below `threshold × 1.1`. 6. Cross-highlighting: `flag_low_form_count` ambers `form_count`; `flag_high_fta` reds `pct_fta` and `patient_fta`; `flag_low_operator_pct` ambers `pct_operator` and `operator_count`; `flag_low_pt_seen` reds `patient_seen`; any `ci_count > 0` reds `ci_count`. 7. Flag cells: info flags → blue when set / white when not; triggered low-tier-only flags → amber; triggered high-tier **or unclassified** flags → red; untriggered → green. 8. Widths: name 24, `flags_detail` 40, everything else 9; freeze panes at `A4`.

**Side effects** — writes the "Summary" worksheet.

**Calls** — `_styleHeader`, `_styleColumnHeaders`, `_fill`, `_thin_border`, `config.resolve_flags`, `config.resolve_tiers`.

#### `_build_scale_trends_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 552–617.* Sheet **"Scale Trends"** — per student: `avg_es, es_slope, first_third_es, last_third_es, avg_gr, gr_slope, first_third_gr, last_third_gr, avg_score, score_slope, avg_ts, avg_cs, avg_ps`.

**Behaviour** — Slope cells: red when `val < thresholds["slope"]` (default 0.0), green when `val > 0`, otherwise plain. Average cells: red below threshold, amber below `threshold × 1.1`. Values are written twice (once by `to_excel`, once by the styling loop). Freeze panes `B4`.

#### `_build_level_distribution_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 620–675.* Sheet **"Level Distribution"** — `es_lvl1..4_pct`, `gr_lvl1..5_pct`, `ts_lvl1..4_pct`, `cs_lvl1..2_pct`, `ps_lvl1..2_pct`.

**Behaviour** — "Bad" levels are ES L1, GR L1 and L2, TS L1, CS L1, PS L1: **red above 20 %, amber above 10 %**. "Good" levels are ES L3/L4, GR L4/L5, TS L3/L4: **green above 50 %**. These cut-offs are hard-coded (lines 662–670) and are *not* configurable.

#### `_build_comparison_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 678–739.* Sheet **"Item Comparison"** (Simulation) or **"Section Comparison"** (Clinic). Returns immediately if `compDf` is empty.

**Behaviour** — Writes `student_number, student_name, item_code|Section, count, cohort_avg_count (rounded 2 dp), pct_of_cohort, behind`. `pct_of_cohort` is **red below 0.5, amber below 0.9, green otherwise**. `behind` is rendered `"✓"` on red or `""` on green.

#### `_build_count_pivot_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 742–763.* Sheet **"Item Code Count Pivot"** / **"Section Count Pivot"**. Builds the pivot with `_buildCountPivot`, returns early if empty, then colours the **bottom 25 % of each column** red via `_colorPivotLowCells`.

#### `_build_gr_pivot_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 766–797.* Sheet **"Item Code GR Pivot"** / **"Section GR Pivot"** from `_buildGrPivot`. Cell colouring: **red below 2.5, amber below 3.0, green at 4.0 or above** (hard-coded, lines 786–791). Freeze panes `C4`.

#### `_build_clinical_incidents_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 800–850.* Sheet **"Clinical Incidents"** — every `cohortDf` row whose `clinical_incident` is non-null and not blank after stripping, showing `student_number, student_name, datetimeutc (date only), assessor_name, clinical_incident, role, clinic`, sorted by student name then date. Column widths are keyed by field name (incident details 70 chars). **Requires** all seven columns to exist in `cohortDf` or raises `KeyError`.

#### `_build_legend_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 853–981.* Sheet **"Legend"** — created via `writer.book.create_sheet` (so it lands at the end of the workbook regardless of position in `config.sheets`).

**Behaviour** — 1. Threshold reference rows are derived from the *active* flag specs, deduplicated by `thresh_key`, labelled via `_THRESH_LABELS` (lines 874–882). `CustomFlagSpec`s get a row with value `"—"`. 2. Always appends `improvement_margin`, `behind_ratio` and a "Borderline reference" row that states the GR level, whether the borderline method is on, and `borderline_n`. 3. Colour key (red/amber/green/blue). 4. Info-flag list if `config.info_flags`. 5. Flag-tier table listing only tier keys that are also in `config.flags`, plus an `!! Unclassified` row if `config.unclassified_flags()` is non-empty. 6. Hard-coded level-distribution colour rules. 7. Scale reference — the documented meaning of each scale: **ES/PR 1–4** (1 = not ready, 2 = direct supervision, 3 = periodic supervision, 4 = indirect supervision); **GR 1–5** (1 = Unsatisfactory, 2 = Borderline, 3 = Satisfactory, 4 = Good, 5 = Excellent); **TS 1–4** (1 = not completed, 2 = safe to leave, 3 = completed, 4 = completed + records); **CS 1–2**; **PS 1–2**; **Score 0–1** (Done well = 1.0, Done = 0.8, Mostly = 0.6, Sometimes = 0.4, Not done = 0.0). 8. Column widths `[22, 14, 65, 0]` — column D is set to width **0**.

##### Nested

| Name | Signature | One line |
|---|---|---|
| `_lh` | `_lh(row, text)` | Merged navy section heading across `A:D` |
| `_lr` | `_lr(row, label, value, note="")` | Bold label / value / italic note row with borders |

#### `_buildItemCountPivot(cohortDf, reportableItems=None)`

*Lines 1017–1077.* Student × reportable item-code **count** pivot, counting only rows whose `role`, stripped, is `""` or `"Operator"` (line 1034 — blank role counts as Operator).

**Parameters** — `reportableItems` defaults to `DDS3_REPORTABLE_ITEMS`.

**Returns** — `(pivot, item_to_cat)`; `(empty DataFrame, item_to_cat)` when no records match.

**Behaviour** — 1. Accepts `item_codes` as a list or a JSON string (silently skipping unparsable strings). 2. Keeps only codes in the reportable set. 3. Uses `_canonicalNameMap(cohortDf)` for names. 4. Inserts missing reportable columns as 0 and sorts item columns **numerically** with `int(x)` — which raises `ValueError` on any non-numeric item code.

#### `_buildItemScaleDist(cohortDf, reportableItems=None)`

*Lines 1081–1133.* Item-code × scale-label count table across the whole cohort.

**Returns** — DataFrame with `Category, Item Code, Done Well, Done, Mostly, Sometimes, Not Done, Not Observed, Avg Score`.

**Behaviour** — 1. Operator-only filter as above. 2. Reads `row["assessor_data"]` (must already be a `dict` — strings are skipped here, unlike `_buildItemCountPivot`), and for each reportable item code counts every sub-item value mapped through `_SCORE_TO_LABEL`. 3. `Avg Score` is the mean of `row["scores"][code]["score"]` across forms, rounded to 3 dp, `np.nan` if none. Note `np.isnan(s)` at line 1119 assumes `s` is a float.

#### `_build_reportable_items_pivot_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 1137–1278.* Sheet **"Reportable Items"** — student × item-code counts with a merged category band on row 2, headers on row 4, data from row 5, and a three-row navy footer of Cohort Avg / Min / Max.

**Behaviour** — Per-cell colouring versus that item's cohort average: **red below `avg × 0.5`, amber below `avg × 0.8`**, plain otherwise; skipped entirely when the item's cohort average is 0. `reportableItems` is read as `getattr(config, "reportableItems", None) or DDS3_REPORTABLE_ITEMS` — but `FlaggingConfig` has no such attribute, so it is always the DDS3 list.

#### `_build_item_scale_dist_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 1282–1336.* Sheet **"Item Scale Distribution"** — the `_buildItemScaleDist` table, with each scale column tinted by its own fixed colour (Done Well/Done green, Mostly amber, Sometimes/Not Done red, Not Observed grey) whenever the count is greater than 0.

#### `_build_operator_by_clinic_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 1340–1423.* Sheet **"Operator by Clinic"** — one row per (student, clinic) with `Operator`, `Support`, `FTA` and `Total` form counts. Returns early if `cohortDf` has no `clinic` column; `clinic` nulls become `"Unknown"`.

**Behaviour** — 1. `Operator` counts `role == "Operator"`, `Support` counts `role == "Support Operator"`, `FTA` counts rows whose `patient_details` contains `"FTA"` (upper-cased), `Total` is the group size. 2. A per-clinic cohort-average frame (`clinic_avg`, with `student_number = -1` and `student_name = "Cohort Avg"`) is computed and used for the colour reference — **but it is never written to the sheet**. 3. The colouring loop reds an `FTA` cell when `val > avg × 1.5`.

> The function ends mid-logic at line 1423: the `Operator` branch of the colour loop has no body, there is no amber/green case, and no column widths or freeze panes are set. See §7.

##### Nested

| Name | Signature | One line |
|---|---|---|
| `_is_fta` | `_is_fta(pd_val)` | `"FTA" in str(pd_val).upper()` |

#### `_render_donut(sd, count, px=_PIE_PX, dpi=96)`

*Lines 1435–1460.* Renders a tiny transparent donut PNG into a `BytesIO`.

**Returns** — the buffer, or `None` when all six slice values are 0.

**Behaviour** — Slices are `sd["O1"]..sd["O6"]` in `_PIE_SCALE_COLORS` order, zero-valued slices dropped; wedge width 0.55; `count` printed in the hole at `max(4, px // 10)` pt bold.

**Side effects** — imports `matplotlib` and calls `matplotlib.use("Agg")` **globally** on every invocation, switching the process-wide backend; closes the figure afterwards.

#### `_build_item_scale_donut_sheet(writer, flagDf, compDf, cohortDf, thresholds, cohort, formType, config, mappingFile=None)`
*Lines 1463–1624.* Sheet **"Item Scale Donuts"** — student × reportable item, each cell holding a donut image of the O1–O6 distribution with the total count in the centre. Operator forms only (`role.str.strip().str.lower() == "operator"` — note this does **not** treat a blank role as Operator, unlike the other two DDS3 builders).

**Behaviour** — 1. Item columns are flattened in `DDS3_REPORTABLE_ITEMS` category order, with merged category headers (dark slate `2E4057`) on row 2 and item codes on row 3. 2. `assessor_data` is parsed from JSON when it is a string. 3. Students come from `flagDf`, sorted by name. 4. Row height 42 pt, column width 6.5; each image is anchored to its cell. 5. A colour legend for O1–O6 is written on the row below the last student, starting at **column 7**. 6. `reportableItems` is hard-coded to `DDS3_REPORTABLE_ITEMS` here — no config hook at all.

**Side effects** — writes the sheet and embeds one PNG per non-empty cell (potentially thousands of images → large files and slow saves).

### 5.7 Core entry points

#### `getFlagDf(cohortDf, formType, config, mappingFile=None)`

*Lines 2119–2379.* **The main computation.** Produces `(flagDf, comparisonDf, thresholds)` from a cohortDf that has already been filtered to assessor-submitted forms and had `calcScore` applied.

**Parameters**

| Name | Type | Default | Description |
|---|---|---|---|
| `cohortDf` | `DataFrame` | — | Form-level rows. Must have `student_number`, `student_name`, `datetimeutc`, `global_rating`, `entrustment`, `time_management`, `communication`, `professionalism`, `scores`, `role`, `patient_details`, `clinical_incident`, `item_codes` |
| `formType` | `str` | — | `"Clinic"` or `"Simulation"` — selects the Section vs item-code comparison branch |
| `config` | `FlaggingConfig` | — | Which flags fire and what thresholds to use |
| `mappingFile` | — | `None` | Clinic only. **Passed on as the `mappingDf` argument of `Utils._mergeSection`**, so it must be a mapping *DataFrame*, not a path (line 2368) |

**Returns** — `(flagDf, comp, thresholds)`. `flagDf` has one row per student sorted by `high_risk_flag_count` then `low_risk_flag_count`, both descending, with the index reset. Returns `(empty, empty, {})` if `cohortDf` is empty, and `(flagDf, empty DataFrame, thresholds)` if there are no item codes at all.

**Behaviour**

1. Copies the input (the caller's frame is **not** mutated) and coerces `datetimeutc` to UTC datetimes and the five scale columns to numeric with `errors="coerce"`.
2. Adds `_mean_score` — the mean of `scores[...]["score"]` over the dict, `NaN` when the dict is empty/absent.
3. Sorts by `datetimeutc` and groups by `student_number`. **`student_name` is taken as `grp["student_name"].iloc[0]`** — the first chronological spelling, *not* `_canonicalNameMap`.
4. Per student computes: `form_count` = number of rows; means `avg_es/gr/ts/cs/ps/score` (rounded 3 dp); slopes `es_slope/gr_slope/score_slope` via `_computeSlope` (rounded 4 dp).
5. **Thirds:** `third = max(1, n // 3)`; `first_third_*` is the mean of the first `third` rows, `last_third_*` the mean of the last `third` rows (rounded 3 dp). For `n < 6` the two windows overlap; for `n <= 2` they are the same single row, which makes `no_improvement_*` fire automatically.
6. **Level distributions** via nested `_lvl_dist`: percentage of non-null ratings at each level, rounded to 1 dp, `0.0` when there are no ratings. Levels: ES/TS 1–4, GR 1–5, CS/PS 1–2.
7. **Roles:** `operator_count` = count of `role == "Operator"`, `support_count` = count of `role == "Support Operator"`, `pct_operator = operator_count / n × 100` (1 dp).
8. **Patients:** `patient_seen` = count of `patient_details == "I saw a patient"` exactly; `patient_fta` = sum of counts for any value whose upper-case form contains `"FTA"`; `pct_patient_seen` and `pct_fta` are those over `n × 100`.
9. **Clinical incidents:** `ci_count` = number of non-null `clinical_incident` values that are non-blank after stripping. (`has_ci`, line 2205, is computed and never used.)
10. Resolves the `thresholds` dict (§5.5) and **prints every threshold to stdout**.
11. Applies each active spec: `FlagSpec` → a vectorised `<` or `>` comparison; `CustomFlagSpec` → `flagDf.apply(lambda row: spec.fn(row, thresholds), axis=1)`.
12. Splits the flag columns: info flags (from `config.info_flags`) are excluded from scoring; the rest are partitioned by `config.resolve_tiers()` into `HIGH_RISK_COLS` / `LOW_RISK_COLS`; anything left over triggers a printed WARNING and counts in neither.
13. `high_risk_flag_count` / `low_risk_flag_count` are the row-wise sums of those boolean columns (`0` if the list is empty). `flags_detail` joins the triggered flag names with `"flag_"` stripped.
14. Sorts by the two risk counts descending.
15. **Comparison frame:** `_itemCodeCounts(df)` → for Simulation, `cohort_avg_count = total count for that item_code / nStudents` (where `nStudents = flagDf["student_number"].nunique()`); for Clinic, item codes are first merged to Sections via `Utils._mergeSection` and summed per (student, Section) before the same average. Then `behind = count < cohort_avg_count × behind_ratio` and `pct_of_cohort = count / cohort_avg_count` (±inf → NaN, rounded 3 dp). Names are attached from `_canonicalNameMap(df)` via a left merge on `student_number`.

**Side effects** — prints the threshold table and any unclassified-flag warning to stdout. Reads the item-section mapping Excel file when `formType != "Simulation"` and `mappingFile` is falsy.

**Calls** — `flagging_utils:_computeSlope`, `flagging_utils:_itemCodeCounts`, `flagging_utils:_canonicalNameMap`, `Utils:_loadSectionMapping`, `Utils:_mergeSection`, `config.resolve_flags`, `config.resolve_tiers`.

**Called by** — `main.ipynb` (inside `createFlaggingReport`).

##### Nested

| Name | Signature | One line |
|---|---|---|
| `_meanScore` | `_meanScore(scoresDict)` | Mean of `v["score"]` over the `scores` dict; `NaN` if not a non-empty dict or no scores |
| `_lvl_dist` | `_lvl_dist(series, levels)` | Percentage at each rating level (1 dp), `0.0` for every level when there are no values |
| `_auto` | `_auto(col, override)` | `override` if given, else `round(mean − sdMultiplier·SD, 3)` |
| `_autoBorderline` | `_autoBorderline(col, override)` | `override` if given, else the mean of `col` among borderline-GR peers, falling back to `_auto` |

**Example** (from `main_notebook_code.py`, inside `createFlaggingReport`):

```python
cohortDf = getDataDf(engine, cohort, filters=filters)
removeStudents = REMOVE_STUDENTS_DICT.get(cohort, [])
cohortDf = cohortDf[~cohortDf["student_number"].isin(removeStudents)]
cohortDf["scores"] = cohortDf.apply(lambda row: calcScore(row, SCORE_MAP), axis=1)

flagDf, compDf, thresholds = getFlagDf(cohortDf, formType=formType, config=config)
```

#### `_itemCodeCounts(df)` — second definition (the effective one)

*Lines 2385–2406.* Counts `(student_number, item_code)` form occurrences from the raw cohort data.

**Behaviour** — 1. Skips rows where `item_codes` is `None`. 2. Parses JSON strings, skipping the row on failure. 3. Skips values that are not a `list` or `set`. 4. Skips falsy codes **and any code whose string starts with `"scale"`** (line 2401) — this is the filter that keeps scale placeholders out of the comparison sheet. 5. Returns a bare empty `DataFrame()` (no columns) when nothing matched — callers must check `.empty` before using `["item_code"]`.

**Called by** — `getFlagDf`, `_buildCountPivot` (both resolve to this definition, shadowing the one at line 57).

#### `saveFlagDfToPdf(flagDf, compDf, thresholds, cohortDf, filepath, formType, cohort, config, mappingFile=None)`

*Lines 2412–2654.* Generates the companion landscape-A4 PDF via `reportlab` (imported locally).

**Behaviour** — 1. **Section 1 — Student Risk Summary:** title with `pd.Timestamp.now()` date, then a table of the stat columns that exist in `flagDf` (`student_name, form_count, operator_count, pct_operator, patient_seen, patient_fta, pct_fta, ci_count, high_risk_flag_count, low_risk_flag_count, avg_es, avg_gr, avg_score`) plus one narrow column per flag. Flags render as `"✓"`; floats are formatted to 1 dp. Risk-count cells use the same white→red / white→amber gradients as the Summary sheet; triggered flag cells are blue (info), amber (low-tier only) or red (high-tier/unclassified). 2. **Section 2 — Item Scale Distribution** from `_buildItemScaleDist(cohortDf, DDS3_REPORTABLE_ITEMS)`, each scale column tinted. 3. **Section 3 — Reportable Item Counts** from `_buildItemCountPivot(cohortDf, DDS3_REPORTABLE_ITEMS)`, split into one sub-table per category (explicitly to avoid a 47-column-wide table), each with Cohort Avg / Min / Max footer rows and **red below 50 % of the item's cohort average, amber below 80 %**. 4. `doc.build(story)` and prints the path.

**Side effects** — **writes a PDF** to `filepath`; prints. Sections 2 and 3 are each wrapped in a bare `try/except Exception` that only prints `[PDF] … section skipped: {e}` (lines 2589 and 2650), so a broken DDS3 section produces a silently truncated PDF. Both sections use `DDS3_REPORTABLE_ITEMS` unconditionally, regardless of cohort.

**Calls** — `flagging_utils:_buildItemScaleDist`, `flagging_utils:_buildItemCountPivot`, `config.resolve_flags`, `config.resolve_tiers`. **Called by** — `saveFlagDfToExcel2` (only when `config.createPdf`).

##### Nested

| Name | Signature | One line |
|---|---|---|
| `_hdr_style` | `_hdr_style(n_cols, col_widths)` | Shared reportlab `TableStyle`: navy header row, 7 pt, grid, zebra row backgrounds. `n_cols` and `col_widths` are accepted but never used inside |

#### `saveFlagDfToExcel2(flagDf, compDf, thresholds, cohortDf, filepath, formType, cohort, config, mappingFile=None)`

*Lines 2657–2682.* Writes the full flagging workbook — the sheets and their order come entirely from `config.sheets`.

**Parameters**

| Name | Type | Default | Description |
|---|---|---|---|
| `flagDf`, `compDf`, `thresholds` | — | — | The three outputs of `getFlagDf` |
| `cohortDf` | `DataFrame` | — | The original form-level frame (several sheets re-derive from it) |
| `filepath` | `str` | — | Destination `.xlsx` path |
| `formType`, `cohort` | `str` | — | Used in every sheet banner and in sheet-name selection |
| `config` | `FlaggingConfig` | — | Drives sheets, flags and `createPdf` |
| `mappingFile` | — | `None` | Forwarded to each builder (here it should be a *path*, unlike in `getFlagDf`) |

**Returns** — `None`.

**Behaviour** — 1. Opens `pd.ExcelWriter(filepath, engine="openpyxl")`. 2. Iterates `config.sheets` **directly** (not `config.resolve_sheets()`), printing and skipping unknown keys instead of raising. 3. Calls each builder inside a `try/except Exception` that prints `[saveFlagDfToExcel2] Sheet '<key>' failed: {e}` and continues. 4. Prints the saved path. 5. If `config.createPdf` is truthy, calls `saveFlagDfToPdf` with `filepath.replace(".xlsx", ".pdf")`, catching and printing (with traceback) any failure.

**Side effects** — **writes the `.xlsx`** (and optionally the `.pdf`); prints progress and per-sheet failures.

**Calls** — every entry in `SHEET_REGISTRY` used by the config, plus `flagging_utils:saveFlagDfToPdf`. **Called by** — `main.ipynb` (inside `createFlaggingReport`).

**Example** (from `main_notebook_code.py`):

```python
import os
os.makedirs(cohort, exist_ok=True)
filename = f"{cohort} {formType} {clinic + ' ' if clinic else ''}Flagging (2026).xlsx"
saveFlagDfToExcel2(
    flagDf, compDf, thresholds, cohortDf,
    filepath=f"{cohort}/{filename}",
    formType=formType,
    cohort=cohort,
    config=config,
)
```

The only uncommented invocation in the notebook is:

```python
createFlaggingReport("DDS3", "Clinic", config=PRESETS["dds3_clinic"])
```

---

## 6. Call graph (this module)

Restricted to functions with at least one intra-module edge, split by section.

### 6.1 Computation path

```mermaid
flowchart LR
  getFlagDf["getFlagDf"] --> computeSlope["_computeSlope"]
  getFlagDf --> itemCodeCounts["_itemCodeCounts (line 2385)"]
  getFlagDf --> canonicalNameMap["_canonicalNameMap"]
  saveExcel["saveFlagDfToExcel2"] --> savePdf["saveFlagDfToPdf"]
  savePdf --> buildItemCountPivot["_buildItemCountPivot"]
  savePdf --> buildItemScaleDist["_buildItemScaleDist"]
  buildItemCountPivot --> canonicalNameMap
  buildCountPivot["_buildCountPivot"] --> itemCodeCounts
```

### 6.2 Sheet builders → styling helpers

```mermaid
flowchart LR
  subgraph builders["Sheet builders (SHEET_REGISTRY)"]
    summary["_build_summary_sheet"]
    trends["_build_scale_trends_sheet"]
    levels["_build_level_distribution_sheet"]
    comparison["_build_comparison_sheet"]
    countpvt["_build_count_pivot_sheet"]
    grpvt["_build_gr_pivot_sheet"]
    ci["_build_clinical_incidents_sheet"]
    legend["_build_legend_sheet"]
    repitems["_build_reportable_items_pivot_sheet"]
    scaledist["_build_item_scale_dist_sheet"]
    opclinic["_build_operator_by_clinic_sheet"]
    donuts["_build_item_scale_donut_sheet"]
  end
  subgraph helpers["Helpers"]
    fill["_fill"]
    border["_thin_border"]
    hdr["_styleHeader"]
    colhdr["_styleColumnHeaders"]
    lowcells["_colorPivotLowCells"]
    bcp["_buildCountPivot"]
    bgp["_buildGrPivot"]
    bicp["_buildItemCountPivot"]
    bisd["_buildItemScaleDist"]
    donut["_render_donut"]
  end
  summary --> hdr & colhdr & fill & border
  trends --> hdr & colhdr & fill & border
  levels --> hdr & colhdr & fill & border
  comparison --> hdr & colhdr & fill & border
  ci --> hdr & colhdr & fill & border
  scaledist --> hdr & colhdr & fill & border
  opclinic --> hdr & colhdr & fill & border
  countpvt --> bcp & lowcells & hdr & colhdr
  grpvt --> bgp & hdr & colhdr & fill
  legend --> fill & border
  repitems --> bicp & hdr & fill & border
  scaledist --> bisd
  donuts --> donut & fill & border
  hdr --> fill
  colhdr --> fill & border
  lowcells --> fill
```

---

## 7. Gotchas and known issues

**Duplicate / dead definitions**

- **`_itemCodeCounts` is defined twice** — line 57 and line 2385. The later definition wins for every caller, so the line-57 version (which returns a *typed* empty DataFrame and does not filter `"scale*"` codes) is dead code that reads as if it were live. Anyone editing the version at line 57 will see no effect.
- **`_levelDistribution` (lines 72–77) is never called.** `getFlagDf` uses its own nested `_lvl_dist` (line 2181), which differs in behaviour: it returns `0.0` for empty input where `_levelDistribution` returns `np.nan`.
- `has_ci` (line 2205) is computed and never used. `pct_patient_seen` (line 2202) is stored on `flagDf` but appears on no sheet.
- Unused imports: `os` (line 6), `re` (line 7), `variableUtils` (line 11), `List`/`Optional` (line 13), `GradientFill` (line 15), `FORMAT_NUMBER_00` (line 16), and 8 of the 10 names imported from `Utils` on line 14 (`createTable`, `addPlotImage`, `getBannerDrawer`, `getmodeArgs`, `readDf`, `runDdl`, `toInt`, `autoFitColumns`). Only `_loadSectionMapping` and `_mergeSection` are used. The module-level `matplotlib.pyplot` import (line 10) is also redundant — `_render_donut` re-imports it locally.

**Truncated function**

- **`_build_operator_by_clinic_sheet` stops mid-statement at line 1423.** The colour loop at lines 1415–1423 iterates `[("Operator", …), ("FTA", …)]` but only has a body for `FTA` (`val > avg × 1.5` → red); the `Operator` branch does nothing, there is no amber/green case, the `clinic_avg` "Cohort Avg" rows computed at lines 1373–1377 are never written to the sheet, and no column widths or `freeze_panes` are set. The two blank lines before the next section (1424–1426) suggest an edit was lost.

**Threshold formulas that don't match their documentation**

- `thresholds["forms"]` (line 2280) and `thresholds["min_pt_seen"]` (line 2287) **ignore `config.sdMultiplier`** — they are always `mean − 1·SD`, while `es/gr/ts/cs/ps/score` use `mean − sdMultiplier·SD`. Presets that set `sdMultiplier = 1.5` (`sim_standard`, `boh2_sim`, `boh2_clinic`, `dds2_clinic`, `dds3_clinic`) therefore mix two different auto rules in one run.
- `thresholds["forms"]` uses `int(...)` rather than `round(...)`, truncating toward zero, and can go negative for a cohort with a large SD (a negative minimum means `low_form_count` can never fire).
- `FlaggingConfig.describe()` (lines 1880–1892) prints "auto = cohort mean - 1 SD" for every auto threshold, which is wrong whenever `sdMultiplier != 1.0`, and does not mention the borderline method for ES/TS/CS/PS/Score at all in that table (it is described separately at lines 1868–1871).
- `thresholds["sd_multiplier"] = config.sdMultiplier or 1.0` — a deliberate `sdMultiplier = 0` silently becomes `1.0` (same trick inside `_auto`, line 2248).

**Flag semantics that surprise people**

- **NaN never fires a flag.** Students with missing scale data or a single form (so `NaN` slopes) escape `low_*` and `declining_*` entirely, and will look "clean" on the Summary sheet.
- **`high_es_lvl2` cannot fire at its default threshold** of `maxEsLvl2Pct = 100.0` — no percentage exceeds 100. Every preset that lists the flag (including `dds3_clinic`, which also puts it in `lowTierFlags`) leaves it at 100.0, so the `ES L2%` column is permanently green.
- **`no_improvement_*` uses `<=` with `improvementMargin = 0.0`**, so a flat trajectory counts as "no improvement"; and because `third = max(1, n // 3)` (line 2175), a student with 1–2 forms has identical first/last thirds and is guaranteed to fire it.
- `resolve_tiers()` silently reclassifies a key present in **both** tier lists as HIGH (with a printed warning only), and ignores unknown keys.
- A flag in `config.flags` but in neither tier list still fires and still shows in Excel — coloured **red** by `_build_summary_sheet` (the "unclassified defaults to severe" branch at lines 528–531) — while counting toward neither risk column. The only signal is a printed warning at line 2328.

**Hard-coded values that are not configurable**

- Level-distribution colour cut-offs (20 % / 10 % bad, 50 % good) — lines 662–670.
- GR pivot colour cut-offs (2.5 / 3.0 / 4.0) — lines 786–791.
- Comparison-sheet `pct_of_cohort` cut-offs (0.5 / 0.9) — lines 720–723.
- Reportable-item cut-offs (50 % / 80 % of cohort average) — lines 1237–1242 and 2634–2637.
- `_colorPivotLowCells` bottom-quartile default 0.25, and its `threshold > 0` guard which silently disables colouring for sparse columns.
- `DDS3_REPORTABLE_ITEMS` is dated *2026-07* and sourced from *DDS3 Reportable Item numbers.xlsx*; it is baked into the module. `_build_item_scale_donut_sheet` (line 1472) and both PDF sections (lines 2562, 2594) use it unconditionally for **any** cohort. The other two DDS3 builders read `getattr(config, "reportableItems", None)`, but `FlaggingConfig` never defines that attribute, so the getattr is always `None` — the hook does not work.
- The notebook's output filename hard-codes the year: `f"{cohort} {formType} … Flagging (2026).xlsx"`.

**Error handling that hides problems**

- `saveFlagDfToExcel2` wraps every sheet builder in `except Exception` and only prints (line 2670). A cohortDf missing, say, `clinical_incident` produces a workbook that is silently short a sheet. If *every* sheet fails, the `ExcelWriter` context exits with no worksheets, which openpyxl will reject at save time.
- `saveFlagDfToExcel2` iterates `config.sheets` directly instead of `config.resolve_sheets()`, so the `KeyError`-with-help-text path in `resolve_sheets` never runs from the main entry point — unknown sheet keys are just printed and skipped.
- `saveFlagDfToPdf`'s two DDS3 sections each swallow all exceptions (lines 2589, 2650).
- `_buildItemCountPivot` (line 1039) and `_itemCodeCounts` (line 2395) swallow JSON parse errors with bare `except Exception`, silently dropping the row's item codes.

**Inconsistent contracts**

- `mappingFile` means two different things. The sheet builders and `_buildCountPivot`/`_buildGrPivot` pass it to `_loadSectionMapping`, so it must be a **path**. `getFlagDf`'s Clinic branch does `mappingFile = mappingFile or _loadSectionMapping(None)` and then passes it as the `mappingDf` argument of `_mergeSection` (line 2368), so it must be a **DataFrame**. Passing a path to `getFlagDf` will break the section merge.
- Three different "which rows count as Operator" rules coexist: `_buildItemCountPivot` and `_buildItemScaleDist` treat a **blank** role as Operator (`not in ("", "Operator")` → skip, lines 1034 and 1099); `_build_item_scale_donut_sheet` requires `role.strip().lower() == "operator"` (line 1485); `getFlagDf` counts `role == "Operator"` exactly (line 2195).
- Two different name-resolution rules coexist: `getFlagDf`'s per-student aggregation takes `grp["student_name"].iloc[0]` (line 2161) and `_buildCountPivot` uses `drop_duplicates()`, while `_canonicalNameMap` (most-frequent spelling) is used only for `compDf` and `_buildItemCountPivot`. A student with inconsistent name spellings can therefore show one name on the Summary sheet and another on the Comparison / Reportable Items sheets.
- `_buildItemCountPivot` sorts item columns with `key=lambda x: int(x)` (line 1075) — a non-numeric reportable item code would raise `ValueError`.

**Performance / output size**

- `_build_item_scale_donut_sheet` renders one matplotlib figure per non-empty (student × item) cell and embeds it as a PNG. For a full DDS3 cohort × 51 item codes this is potentially thousands of images — slow to build and a very large `.xlsx`. `_render_donut` also calls `matplotlib.use("Agg")` on every call, changing the backend for the whole process.
- `getFlagDf`, `_buildGrPivot`, `_buildItemCountPivot` and `_buildItemScaleDist` all use row-by-row `iterrows()` over the form-level frame.

**Cosmetic**

- The Legend sheet sets column D to width **0** (line 980–981), hiding it.
- `_build_legend_sheet` and `_build_item_scale_donut_sheet` create their sheets with `writer.book.create_sheet`, so they are appended at the end of the workbook regardless of their position in `config.sheets`.
- `_hdr_style` inside `saveFlagDfToPdf` takes `n_cols` and `col_widths` and uses neither.
- `_build_scale_trends_sheet` and `_build_level_distribution_sheet` write every value twice — once via `to_excel`, once in the styling loop.
- Indentation of the `high_es_lvl2` entry in `FLAG_REGISTRY` (lines 317–320) does not match the surrounding entries.
